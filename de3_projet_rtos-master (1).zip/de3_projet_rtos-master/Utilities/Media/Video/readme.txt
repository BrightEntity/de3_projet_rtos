This directory contains a movie (*.emf) file
to be used with the following projects:
- BirdsAndFeeder.avi
   - /Projects/STM32F412G-Discovery/Demonstrations
   - /Projects/STM32F413H-Discovery/Demonstrations

- Plane_480x272.emf
   - /Projects/STM324x9I_EVAL/Demonstrations
   - /Projects/STM32F429I-Discovery/Demonstrations
   - /Projects/STM32469I_EVAL/Demonstrations
   - /Projects/STM32469I-Discovery/Demonstrations

- Plane_320x240.emf
   - /Projects/STM324xG_EVAL/Demonstrations
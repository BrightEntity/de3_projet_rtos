/*
 * taskdef.h
 *
 *  Created on: Jan 20, 2021
 *      Author: florentgoutailler
 */

#ifndef TASKDEF_H_
#define TASKDEF_H_

//extern variable
extern uint32_t RTOS_RunTimeCounter;

//Tasks
void vTask0( void *);

#endif /* TASKDEF_H_ */
